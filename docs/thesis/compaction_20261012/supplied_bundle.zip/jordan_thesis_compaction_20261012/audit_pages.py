#!/usr/bin/env python3
"""Read-only physical PDF page inventory. Requires PyMuPDF (import fitz).

Optional --body-start / --body-end are human-verified, 1-based physical pages.
Page labels are reported but never assumed to delimit body text.
Blank candidates require visual confirmation; no pages are removed.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys


def inventory(path: Path, body_start: int | None = None, body_end: int | None = None) -> dict:
    import fitz
    with fitz.open(path) as doc:
        if (body_start is None) != (body_end is None):
            raise ValueError("Supply both body bounds or neither")
        if body_start is not None and not (1 <= body_start <= body_end <= len(doc)):
            raise ValueError("Body bounds must be valid 1-based physical page numbers")
        rows = []
        for i, page in enumerate(doc, 1):
            text = page.get_text("text").strip()
            blank = not text and not page.get_images() and not page.get_drawings() and not list(page.annots() or [])
            region = ("unassigned" if body_start is None else
                      "front" if i < body_start else "body" if i <= body_end else "back")
            rows.append({"physical_page": i, "page_label": page.get_label(),
                         "region": region, "text_characters": len(text),
                         "blank_candidate": blank})
        result = {"file_name": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                  "total_physical_pages": len(doc), "body_bounds_supplied": body_start is not None,
                  "regions_including_blanks": {r: sum(p["region"] == r for p in rows)
                                                for r in sorted({p["region"] for p in rows})},
                  "blank_candidates": [p["physical_page"] for p in rows if p["blank_candidate"]],
                  "outline": doc.get_toc(), "pages": rows,
                  "warning": "Visual confirmation required. Numbering is not content scope; blanks already count in region totals."}
        return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--body-start", type=int)
    parser.add_argument("--body-end", type=int)
    args = parser.parse_args()
    try:
        result = inventory(args.pdf, args.body_start, args.body_end)
    except (OSError, ValueError, ImportError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
