# Revised supervisor review package — 20 October 2026

Start with FOR_SUPERVISOR.md and jordan_thesis_supervisor_review_20261020.pdf.
The PDF has 70 physical pages. This is a review draft, not completed university
submission paperwork or independent mathematical certification.

## Build the paper

From repository/thesis, run `latexmk -lualatex main.tex` using LuaLaTeX, Biber,
Libertinus and DejaVu Sans Mono. Existing figure PDFs are included. New TikZ
sources use standalone, pgf, preview and the shared figure style.
The build report binds every LaTeX/BibTeX/figure input to the included PDF.

## Code and earlier experimental archives

Repository: https://github.com/YixueWang983/jordan-sorting
Production source baseline: 19a553fb9a089fae726c4ba49c5412a9e4bd12d3
Formal producing source: 4a83fa6b7a4213e9e5758fe3454e002ebc266459
The production Python trees are identical. Formal results and old qualification
archives remain at their original fixed versions; the paper's Appendix B gives
the exact archive locations. This package does not contain all older raw data.

For new read-only checks, use a fresh checkout of the baseline and place the
bundled repository/thesis and new docs/validation/thesis_revision_20261020
folder at the corresponding paths. Do not overwrite prior archives. Read the
new folder's README for the exact checks and optional fresh-directory commands.
The local supplementary records are included, as are the four supplied originals.
The latter's aggregates must not be relabelled as project verification.

## Integrity

SHA256SUMS.json at package root lists every other ZIP member. The validation
folder has its own manifest. The ZIP sidecar SHA-256 is outside this package.
All diagnostic outputs are checked; hook-removal variants are experimental,
not production backends that passed the full qualification protocol.
