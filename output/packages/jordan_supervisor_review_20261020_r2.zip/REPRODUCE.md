# Supervisor review package: second correction, 20 October 2026

Start with FOR_SUPERVISOR.md and jordan_thesis_supervisor_review_20261020_r2.pdf.
The PDF has 70 physical pages. This is a review draft. The author directs the
research and uses Codex as an assistant; no authorship percentage is assigned.
The AI-use inventory and personal reflection still require author completion.

## Build
From repository/thesis, run `latexmk -lualatex main.tex` with LuaLaTeX, Biber,
Libertinus and DejaVu Sans Mono. Figure PDFs are included.
docs/validation/thesis_review_round2_20261020/build_report.json binds the PDF
to the included sources. Main typography and layout settings are unchanged.

## Code and full historical evidence
https://github.com/YixueWang983/jordan-sorting/tree/2da8b662bf3c50c1bd51ee85ed2215a72a34f7c7
is the fixed repository baseline. The formal producer remains
4a83fa6b7a4213e9e5758fe3454e002ebc266459; the local supplement producer remains
19a553fb9a089fae726c4ba49c5412a9e4bd12d3. No production source or old measurement
was changed. This package does not duplicate all earlier raw formal archives.

For the new read-only checks, use a checkout of the baseline and the bundled
revised thesis and new docs/validation/thesis_review_round2_20261020 directory.
The bundled earlier thesis_revision_20261020 directory is byte-identical to
the baseline, including all local supplementary raw records and its manifest.
Use the NEW local supplement checker against the new 15-row table; the old
checker remains bound to the old thesis at the baseline commit.
Exact full-suite and both formal-validator commands are in the new README.

## Integrity and scope
SHA256SUMS.json at package root covers every other ZIP member. The new review
directory and the preserved earlier directory have separate manifests.
The ZIP's SHA-256 is supplied outside the archive. Numeric reconstruction and
tests are execution evidence, not external mathematical certification.
