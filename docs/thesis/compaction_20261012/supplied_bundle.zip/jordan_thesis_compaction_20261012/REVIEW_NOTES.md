# 首轮精简的审阅说明

## 当前交付

这是两个英文 LaTeX 章节的可审阅替换稿，不是最终 64–66 页论文。
远端仓库、生产源码、实验数据、已归档审核和原 PDF 均未修改。
算法章的规则、两个 z1 问题和反例仍使用已有版本。全部改动均须经作者审阅。

## 减少重复但不能丢掉的事实

1. 当前排序从维护的 partial order 恢复；reference 使用 oracle 输出。
2. 无回滚后的异常传播/丢弃状态，不意味原子更新、自动撤销或可重用状态。
3. stage_results 参与执行检查；trace 开关不能整块关闭它。
4. 两端插入复制、membership/ancestor 扫描和逻辑 split 计数口径完整保留。
5. 单调输入上的 (m-1)^2 复制推导是源码下界，不是对整体输入的紧确复杂度。
6. 旧 60 个输入与 3,600 条测量仍明确属于含回滚实现。
7. 方法中的序列去重仍是历史 family-size 组内规则，没有改写为全局 rank 去重。
8. 回归/同核 replay、独立输出对照、成本证明和计时资格不混称。
9. 资格核对、计时内外、GC、输出恢复、调度、统计单位、拒错和环境仍在正文。
10. 新后端与新实验没有被写成已完成，也没有按计划配额生成任何结果。

## 版本化来源

只读审阅了以下源码文本：
- `thesis/main.tex`，Git blob `009b2226b3f3b9fdb33d6a7b1e952f22dab412c3`。
- `thesis/chapters/implementation.tex`，`4350bfb8f245d3e5bd1e8abb3fa24712a7ef9df1`。
- `thesis/chapters/methodology.tex`，`06a6609bbe7a58a5e06b1702816b1fed1c13acee`。
- `thesis/appendix/claim_traceability.tex`，`2ba2a4c6569c5d57564c9a2a66baf961b6c62cc4`。
- 算法章读到的规则部分用于检查复用引用，不声称本轮重新验证算法或原论文。

完整来源位于 GitHub 仓库 `YixueWang983/jordan-sorting` 的
`2be212a11ceee7453d2f8beebc04337d3690d117`。

## 篇幅规则核实边界

本轮读取 FU AG Software Engineering 的 ThesisRules 网页（2026-10-12 访问）。
其明确是该工作组页面，并引述 2014 硕士规定的 50–80 页；它不能证明本项目
有“总 PDF 不超过 70 页”的学校统一规则，也不足以确定空白页/附录的计入口径。
当前 64–66 与不超过 70 页仅按用户指定的编辑目标执行；本轮不改版式。

## 如何在仓库生成真正的 diff

解压后运行（输出目录必须不存在且位于仓库之外）：

```sh
python3 prepare_patch.py /path/to/jordan-sorting --out-dir /tmp/jordan-chapter-review
```

脚本只读仓库：检查两个旧章节以及 main.tex、附录的 Git blob，核对 replacement
哈希、标签保留、跨章引用、引用键和原图是否存在，然后生成 `chapters.patch`。
它没有写仓库、commit 或 push 功能。基线变化时会拒绝，勿覆盖新工作。

作者审阅后可以先在仓库运行：

```sh
git apply --check /tmp/jordan-chapter-review/chapters.patch
```

通过不等于排版验收。实际应用及完整构建由作者确认；依仓库 `thesis/Makefile`
或既有构建指引执行。不要覆盖历史审阅 PDF，另存本轮产物并记录哈希。

## PDF 页数清单

`audit_pages.py` 依赖 PyMuPDF；只读取实际 PDF，输出 JSON 到标准输出：

```sh
python3 audit_pages.py '/path/to/actual-thesis.pdf' > page_inventory.json
```

根据目录/视觉确认正文的实际物理起止页后，可加 `--body-start N --body-end M`。
该参数不是印刷页码。空白候选页已经包含在分区总数里，不再次相加。

## 本轮没有完成

没有完整 checkout；无法读取用户 Mac 本地路径的 PDF；未执行真实仓库 patch
生成/应用、完整 LaTeX 构建、参考文献重建或原版/新版逐页比较。不能报告真实
净减少页数、声称方法章已到 6–7 页，或将本次版本写为最终审阅稿。
