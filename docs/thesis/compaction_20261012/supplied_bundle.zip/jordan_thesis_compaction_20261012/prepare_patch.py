#!/usr/bin/env python3
"""Prepare a review patch; never modify, commit or push the input repository.

Usage:
    python3 prepare_patch.py /path/to/jordan-sorting --out-dir /tmp/jordan-review-new
The output directory must not exist and must be outside the repository.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys

BASE = "2be212a11ceee7453d2f8beebc04337d3690d117"
TARGETS = {
    "thesis/chapters/implementation.tex": "4350bfb8f245d3e5bd1e8abb3fa24712a7ef9df1",
    "thesis/chapters/methodology.tex": "06a6609bbe7a58a5e06b1702816b1fed1c13acee",
}
GUARDS = {
    "thesis/main.tex": "009b2226b3f3b9fdb33d6a7b1e952f22dab412c3",
    "thesis/appendix/claim_traceability.tex": "2ba2a4c6569c5d57564c9a2a66baf961b6c62cc4",
}

def git_blob(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def uncomment(text: str) -> str:
    return re.sub(r"(?<!\\)%[^\n]*", "", text)

def labels(text: str) -> set[str]:
    return set(re.findall(r"\\label\{([^{}]+)\}", uncomment(text)))

def references(text: str) -> set[str]:
    groups = re.findall(r"\\(?:[Cc]ref|[Vv]ref|[Ee]qref|ref|pageref|autoref)\*?\{([^{}]+)\}", uncomment(text))
    return {k.strip() for group in groups for k in group.split(",")}

def citations(text: str) -> set[str]:
    groups = re.findall(r"\\(?:[Tt]extcite|[Pp]arencite|[Aa]utocite|[Cc]ite)s?\*?(?:\[[^\]]*\])*\{([^{}]+)\}", uncomment(text))
    # A second key in a multicite is checked separately by its presence in the .bib
    # in the static package review; this scanner also captures the second groups.
    for m in re.finditer(r"\\(?:parencites|textcites|autocites)((?:\[[^\]]*\]|\{[^{}]+\})+)", uncomment(text)):
        groups.extend(re.findall(r"\{([^{}]+)\}", m.group(1)))
    return {k.strip() for group in groups for k in group.split(",")}

def prepare(repo: Path, out: Path, package: Path) -> dict:
    repo, out, package = repo.resolve(), out.resolve(), package.resolve()
    if out == repo or repo in out.parents:
        raise ValueError("Output must be outside the repository; no repository writes are allowed")
    if out.exists():
        raise FileExistsError(f"Output already exists: {out}")
    originals, replacements = {}, {}
    # All checks finish before any output directory is created.
    for rel, expected in {**TARGETS, **GUARDS}.items():
        path = repo / rel
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"Missing, non-regular or symlinked source: {rel}")
        raw = path.read_bytes()
        if git_blob(raw) != expected:
            raise ValueError(f"Baseline mismatch: {rel}; preserve changes and review manually")
        if rel in TARGETS:
            originals[rel] = raw.decode("utf-8")
            overlay = package / "overlay" / rel
            if overlay.is_symlink():
                raise ValueError(f"Symlinked overlay: {rel}")
            replacements[rel] = overlay.read_text(encoding="utf-8")
            lost = labels(originals[rel]) - labels(replacements[rel])
            if lost:
                raise ValueError(f"Lost existing labels in {rel}: {sorted(lost)}")
    manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
    for rel, new in replacements.items():
        digest = hashlib.sha256(new.encode("utf-8")).hexdigest()
        if digest != manifest["replacement_sha256"][rel]:
            raise ValueError(f"Overlay hash mismatch: {rel}")
    all_labels = set()
    for path in (repo / "thesis").rglob("*.tex"):
        rel = path.relative_to(repo).as_posix()
        all_labels |= labels(replacements.get(rel, path.read_text(encoding="utf-8")))
    new_text = "\n".join(replacements.values())
    missing_refs = references(new_text) - all_labels
    if missing_refs:
        raise ValueError(f"Unresolved replacement references: {sorted(missing_refs)}")
    bib = (repo / "thesis/bibliography.bib").read_text(encoding="utf-8")
    bib_keys = set(re.findall(r"@\w+\s*\{\s*([^,\s]+)", bib))
    missing_cites = citations(new_text) - bib_keys
    if missing_cites:
        raise ValueError(f"Missing citation keys: {sorted(missing_cites)}")
    for name in re.findall(r"\\includegraphics(?:\[[^\]]*\])?\{([^{}]+)\}", new_text):
        if not (repo / "thesis/figures" / name).is_file():
            raise FileNotFoundError(f"Required existing figure missing: {name}")
    patch = "".join("".join(difflib.unified_diff(
        originals[rel].splitlines(keepends=True), new.splitlines(keepends=True),
        fromfile=f"a/{rel}", tofile=f"b/{rel}")) for rel, new in replacements.items())
    report = {"reviewed_base": BASE, "input_repository_modified": False,
              "affected_files": list(TARGETS), "guards": GUARDS,
              "preserved_label_counts": {p: len(labels(originals[p])) for p in TARGETS},
              "source_build_or_pdf_check_performed": False,
              "patch_sha256": hashlib.sha256(patch.encode()).hexdigest()}
    out.mkdir(parents=True, exist_ok=False)
    (out / "chapters.patch").write_text(patch, encoding="utf-8")
    (out / "preparation_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    try:
        report = prepare(args.repo, args.out_dir, Path(__file__).parent)
    except (OSError, ValueError, KeyError) as exc:
        print(f"STOP: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(report, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
