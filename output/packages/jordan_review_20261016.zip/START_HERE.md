# Jordan Sorting supervisor-review materials, 2026-10-16

Start with output/pdf/jordan_thesis_review_20261016.pdf (68 pages).
Changes/checks: docs/validation/join_proof_correction_20261016/README.md.
Build: cd thesis; latexmk -lualatex main.tex (LuaLaTeX, Biber, DejaVu Sans Mono).

This is a review package, not a signed university submission.
Production execution remains 4a83fa6b7a4213e9e5758fe3454e002ebc266459.
Archive baseline is ce0148bf70f10eb1683e13abe573406413762331.
Repository: https://github.com/YixueWang983/jordan-sorting
Obtain the full checkout for the production modules and original data. The
included check scripts are to be run from that checkout with this revision.
Qualification, calibration, B tables, raw formal records and old receipts
were neither rerun nor rewritten. This ZIP includes the revised thesis sources,
proof documents, PDF and focused checks, not the entire raw measurement archive.
SHA256SUMS.json binds every included member except itself.
