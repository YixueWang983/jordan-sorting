"""Small fixture tests of read-only helpers; not a real-repository build."""
from __future__ import annotations
import importlib.util
from pathlib import Path
import tempfile
import unittest

import audit_pages
import prepare_patch as patch

class ReadOnlyToolTests(unittest.TestCase):
    def test_git_blob_identity(self):
        self.assertEqual(patch.git_blob(b""), "e69de29bb2d1d6434b8b29ae775ad8c2e48c5391")

    def test_labels_references_and_multicites(self):
        t = r"\label{a} \cref{a,b} \parencites{one}{two} % \label{ignored}" + "\n"
        self.assertEqual(patch.labels(t), {"a"})
        self.assertEqual(patch.references(t), {"a", "b"})
        self.assertEqual(patch.citations(t), {"one", "two"})

    def test_missing_baseline_rejects_without_creating_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            out = root / "out"
            with self.assertRaises(ValueError):
                patch.prepare(repo, out, Path(__file__).parent)
            self.assertFalse(out.exists())
            self.assertEqual(list(repo.iterdir()), [])

    def test_output_in_repo_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with self.assertRaises(ValueError):
                patch.prepare(root, root / "out", Path(__file__).parent)
            self.assertFalse((root / "out").exists())

    def test_success_prepares_diff_but_never_changes_fixture_repo(self):
        from unittest.mock import patch as mock_patch
        import hashlib
        package = Path(__file__).parent
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo, out = root / "repo", root / "out"
            (repo / "thesis/chapters").mkdir(parents=True)
            (repo / "thesis/appendix").mkdir()
            (repo / "thesis/figures").mkdir()
            new_text = "\n".join((package / "overlay" / rel).read_text() for rel in patch.TARGETS)
            for rel in patch.TARGETS:
                (repo / rel).write_text("% synthetic old chapter\n")
            external = patch.references(new_text) - patch.labels(new_text)
            (repo / "thesis/main.tex").write_text("\n".join("\\label{" + key + "}" for key in external))
            (repo / "thesis/appendix/claim_traceability.tex").write_text("% synthetic guard\n")
            (repo / "thesis/bibliography.bib").write_text("\n".join("@book{" + key + ", title={Fixture}}" for key in patch.citations(new_text)))
            for name in ("family_sibling_structure.pdf", "formal_experiment_pipeline.pdf"):
                (repo / "thesis/figures" / name).write_bytes(b"fixture: presence only, not a PDF build")
            targets = {rel: patch.git_blob((repo / rel).read_bytes()) for rel in patch.TARGETS}
            guards = {rel: patch.git_blob((repo / rel).read_bytes()) for rel in patch.GUARDS}
            before = {p.relative_to(repo).as_posix(): p.read_bytes() for p in repo.rglob("*") if p.is_file()}
            with mock_patch.object(patch, "TARGETS", targets), mock_patch.object(patch, "GUARDS", guards):
                report = patch.prepare(repo, out, package)
            self.assertFalse(report["input_repository_modified"])
            self.assertIn("+++ b/thesis/chapters/implementation.tex", (out / "chapters.patch").read_text())
            after = {p.relative_to(repo).as_posix(): p.read_bytes() for p in repo.rglob("*") if p.is_file()}
            self.assertEqual(before, after)

    def test_page_inventory_does_not_assume_body_from_labels(self):
        import fitz
        with tempfile.TemporaryDirectory() as tmp:
            pdf = Path(tmp) / "fixture.pdf"
            with fitz.open() as doc:
                doc.new_page().insert_text((72, 72), "Cover")
                doc.new_page()
                doc.new_page().insert_text((72, 72), "Body")
                doc.save(pdf)
            first = audit_pages.inventory(pdf)
            self.assertEqual(first["total_physical_pages"], 3)
            self.assertEqual(first["blank_candidates"], [2])
            self.assertFalse(first["body_bounds_supplied"])
            explicit = audit_pages.inventory(pdf, 3, 3)
            self.assertEqual(explicit["regions_including_blanks"], {"body": 1, "front": 2})
            self.assertEqual(first["sha256"], explicit["sha256"])
            with self.assertRaises(ValueError):
                audit_pages.inventory(pdf, 3, None)

if __name__ == "__main__":
    unittest.main()
