# Jordan Sorting 章节精简审阅包

基线：`2be212a11ceee7453d2f8beebc04337d3690d117`。

`overlay/thesis/chapters/` 含实现章和方法章的英文替换稿。
`PAGE_BUDGET.md` 是含真实后端与新实验的最终 65 页参考预算。
`REVIEW_NOTES.md` 说明范围、证据保留、基线、复现方法与未执行检查。
`prepare_patch.py` 只读本地完整仓库并在仓库外生成 diff，绝不自动应用或推送。
`audit_pages.py` 输出实际 PDF 的物理页/页码标签/空白候选清单。

本包没有最终论文 PDF，没有真实页数节省测量，没有完整 LaTeX 构建。
静态检查保留了 38 个原有标签；6 个辅助脚本 fixture 测试通过。
fixture 成功并不等于真实仓库应用、图表、引用或整稿排版验收通过。

解压后可以先运行 `python3 -m unittest test_tools -v`。PDF 清单测试需要 PyMuPDF。

本轮不改算法规则、源码、实验、历史图表、附录或模板的字体/行距/页边距/开章规则。
