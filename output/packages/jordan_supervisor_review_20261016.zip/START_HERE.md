# Jordan Sorting: supervisor review package

Completed 17 October 2026; filenames retain the work package start date.

Read `output/pdf/jordan_thesis_supervisor_review_20261016.pdf` (68 physical pages).
The short reading note is `docs/validation/review_delivery_20261016/FOR_SUPERVISOR.md`.
This is a supervisor review draft, not final school submission paperwork.

The package contains the current thesis source, proof documents and a selected
set of review evidence. It does not contain the complete production checkout or
raw qualification/calibration/formal datasets. Obtain those from
https://github.com/YixueWang983/jordan-sorting using the bound versions in the
thesis appendix and `delivery_bindings.json`. No new sorting measurements were run.

To rebuild the PDF, use LuaLaTeX, latexmk, Biber and the fonts named in
`thesis/main.tex`; run `latexmk -lualatex main.tex` inside `thesis`.
The build report binds the exact compiled source and the supplied PDF.

In a full checkout, run the auxiliary checker with ordinary, unoptimized Python:
`python3 docs/validation/join_proof_correction_20261016/audit_crosscheck.py`.
It prints its report; `--output NEW_PATH` saves a new report exclusively.
Optimization flags and PYTHONOPTIMIZE=1/2 are refused before evidence reads.
The auxiliary tools require the full checkout; the archive subset here is not
represented as a self-contained experiment reproduction.

One old evidence-directory script was deliberately maintained. Its historical
manifest still belongs to the old script at `1d3106d9`; that old manifest is not
included as an authority for the revised script. The package root
`SHA256SUMS.json` binds every supplied member except itself, including the fixed
script. `delivery_bindings.json` explains the old/new hashes. All original
performance records, B tables and prior review artifacts remain unchanged.

Proof review, finite execution evidence and wall-clock results are separate
claims. See Table 4.1 and Chapters 4–7 for their limitations.
